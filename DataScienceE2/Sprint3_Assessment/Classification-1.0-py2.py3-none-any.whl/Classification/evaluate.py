import pandas as pd
import numpy as np
import pickle
from sklearn.metrics import f1_score , accuracy_score , roc_auc_score
from Classification.__init__ import * 
actual = pd.DataFrame(actvals,columns=["RainTomorrow"])

def evaluation(): 
    try:
        score = 0
        logistic_score = 0
        svm_score = 0
        decision_score = 0
        mlp_score = 0
        log_pred = pd.read_csv("Logistic_Predictions.csv")
        svm_pred = pd.read_csv("SVM_Predictions.csv")
        decision_pred = pd.read_csv("Decision_Predictions.csv")
        MLP_pred = pd.read_csv("Neural_Predictions.csv")
        if((len(log_pred)!=7908) or (len(svm_pred)!=7908) or (len(decision_pred)!=7908) or (len(MLP_pred)!=7908)):
            print("FS_SCORE:0%")
            print("The 'prediction.csv' file should contain 7908 records")
        else:
            #Logistic Regression
            filename = "Log_Reg.pkl"
            with open(filename, 'rb') as file:
                pickle_model_log = pickle.load(file)

            pickle_model_log = str(pickle_model_log)
            if "LogisticRegression" in pickle_model_log:
                score = score + 5
            else:
                print("Kindly try to use Logistic Regression Model")
            result = round(f1_score(actual, log_pred,average="macro"),2)
            result = result*100
            result1 = round(accuracy_score(actual,log_pred),2)
            result1 = result1*100
            result2 = round(roc_auc_score(actual, log_pred),2)
            result2 = result2*100

            if((result >= 76.0 and result <= 99.0) and (result1 > 80.0 and result1<=99.0) and (result2 >= 80.0 and result2 < 100.0)):
                logistic_score = logistic_score + 20 

            elif((result > 65.0 and result <= 99.0) and (result1 > 70.0 and result1<=99.0) and (result2 >=70.0 and result2 <= 99.0)):
                logistic_score = logistic_score +15

            elif((result > 55.0 and result <= 99.0) and (result1 > 60.0 and result1<=99.0) and (result2 >=60.0 and result2 <= 99.0)):
                logistic_score = logistic_score + 10
                print("Try to improve Logisitic Regression Model")

            elif((result > 50.0 and result <= 99.0) and (result1 > 50.0 and result1<=99.0) and (result2>=50.0 and result2 <= 99.0)):
                logistic_score = logistic_score + 5
                print("Try to improve Logisitic Regression Model")

            else:
                logistic_score = 0
                print("Kindly check your Logisitic Regression Model")

            #SVM
            filename = "SVM.pkl"
            with open(filename, 'rb') as file:
                pickle_model_svm = pickle.load(file)

            pickle_model_svm = str(pickle_model_svm)
            if "SVC" in pickle_model_svm:
                score = score + 5
            else:
                print("Kindly try to use Support Vector Machine Model")

            result = round(f1_score(actual, svm_pred,average="macro"),2)
            result = result*100
            result1 = round(accuracy_score(actual,svm_pred),2)
            result1 = result1*100
            result2 = round(roc_auc_score(actual, svm_pred),2)
            result2 = result2*100


            if((result > 76.0 and result <= 99.0) and (result1 >= 81.0 and result1<=99.0) and (result2 >= 73.0 and result2 < 100.0)):
                svm_score = svm_score + 20 

            elif((result > 65.0 and result <= 99.0) and (result1 > 70.0 and result1<=99.0) and (result2 >=70.0 and result2 <= 99.0)):
                svm_score = svm_score +15

            elif((result > 55.0 and result <= 99.0) and (result1 > 60.0 and result1<= 99.0) and (result2>=60.0 and result2 <= 99.0)):
                svm_score = svm_score + 10
                print("Try to improve Support Vector Machine Model")

            elif((result > 50.0 and result <= 99.0) and (result1 > 50.0 and result1<= 99.0) and (result2>=50.0 and result2 <= 99.0)):
                svm_score = svm_score + 5
                print("Try to improve Support Vector Machine Model")

            else:
                svm_score = 0
                print("Kindly check your Support Vector Machine Model")


            #Decision Tree
            filename = "Decision.pkl"
            with open(filename, 'rb') as file:
                pickle_model_decision = pickle.load(file)

            pickle_model_decision = str(pickle_model_decision)
            if "DecisionTreeClassifier" in pickle_model_decision:
                score = score + 5

            else:
                print("Kindly try to use Decision Tree Classifier Model")


            result = round(f1_score(actual, decision_pred,average="macro"),2)
            result = result*100
            result1 = round(accuracy_score(actual,decision_pred),2)
            result1 = result1*100
            result2 = round(roc_auc_score(actual, decision_pred),2)
            result2 = result2*100

            if((result >= 75.0 and result <= 99.0) and (result1 > 82.0 and result1<=99.0) and (result2 >= 73.0 and result2 <= 99.0)):
                decision_score = decision_score + 20 

            elif((result > 65.0 and result <= 99.0) and (result1 > 70.0 and result1<= 99.0) and (result2>=70.0 and result2 <= 99.0)):
                decision_score = decision_score +15

            elif((result > 55.0 and result <= 99.0) and (result1 > 60.0 and result1<= 99.0) and (result2>=60.0 and result2 <= 99.0)):
                decision_score = decision_score + 10
                print("Try to improve Decision Tree Model")

            elif((result > 50.0 and result <= 99.0) and (result1 > 50.0 and result1<= 99.0) and (result2>=50.0 and result2 <= 99.0)):
                decision_score = decision_score + 5
                print("Try to improve Decision Tree Model")

            else:
                decision_score = 0
                print("Kindly check your Decision Tree Model")


            #Neural Networks
            filename = "Neural.pkl"
            with open(filename, 'rb') as file:
                pickle_model_MLP = pickle.load(file)

            pickle_model_MLP = str(pickle_model_MLP)
            if "MLPClassifier" in pickle_model_MLP:
                score = score + 5

            else:
                print("Kindly try to use MLP Classification Model")

            result = round(f1_score(actual,MLP_pred ,average="macro"),2)
            result = result*100
            result1 = round(accuracy_score(actual,MLP_pred),2)
            result1 = result1*100
            result2 = round(roc_auc_score(actual, MLP_pred),2)
            result2 = result2*100

            if((result > 76.0 and result <= 99.0) and (result1 > 85.0 and result1<=99.0) and (result2 >= 74.0 and result2 <= 99.0)):
                mlp_score = mlp_score + 20 

            elif((result > 65.0 and result <= 99.0) and (result1 > 70.0 and result1<= 99.0) and (result2>=70.0 and result2 <= 99.0)):
                mlp_score = mlp_score +15

            elif((result > 55.0 and result <= 99.0) and (result1 > 60.0 and result1<= 99.0) and (result2>=60.0 and result2 <= 99.0)):
                mlp_score = mlp_score + 10
                print("Try to improve Neural Network Model")

            elif((result > 50.0 and result <= 99.0) and (result1 > 50.0 and result1<= 99.0) and (result2>=50.0 and result2 <= 99.0)):
                mlp_score = mlp_score + 5
                print("Try to improve Neural Network Model")
            else:
                mlp_score = 0
                print("Kindly check your Neural Network Model")

            print("FS_SCORE:{0}%".format(score + logistic_score + svm_score + decision_score + mlp_score))

    except:
        print("FS_SCORE:0%")