# define Python user-defined exceptions
class Error(Exception):
    """Base class for other exceptions"""
    pass


class ValueNotStringError(Error):
    """Raised when the input value is not string"""
    pass


class ValueNotIntError(Error):
    """Raised when the input value is not int"""
    pass


class ValueNotFloatError(Error):
    """Raised when the input value is not float"""
    pass


class ValueNotListError(Error):
    """Raised when the input value is not list"""
    pass

class ListLengthNotMatchError(Error):
    """Raised when the input value list shape not match"""
    pass


class ValueNotDataFrameError(Error):
    """Raised when the input value is not dataframe"""
    pass


class ValueNotMatplotlibAxesError(Error):
    """Raised when the input value is not matplotlib axes"""
    pass


class ValueNotWorldCloudObject(Error):
    """Raised when the input value is not wordcloud object"""
    pass

class ResultDataShapeNotMatchError(Error):
    """Raised when the figure shape is not match with original"""
    pass

class ValueNotNumpyArray(Error):
    """Raised when the input value is not numpy array"""
    pass

class Answer:
    def __save_ans(self, ansNo, obj, back_ward_dir='../'):
        with open(back_ward_dir + ".ans/ans" + ansNo + ".txt", 'w') as f:
            f.write(obj)

    def __get_ans(self, ansNo):
        ans = None
        try:
            with open(".ans/ans" + ansNo + ".txt", "r") as f:
                ans = f.read()
        except FileNotFoundError:
            return None
        return ans
