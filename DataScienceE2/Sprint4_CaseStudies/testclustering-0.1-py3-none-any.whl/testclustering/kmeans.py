import hashlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.testing.compare import compare_images
from matplotlib.testing.compare import ImageComparisonFailure
import matplotlib
import pkg_resources
from . import *


def geth(obj):
    obj = str(obj).encode()
    m = hashlib.md5()
    m.update(bytes(obj))
    return m.hexdigest()


def save_question1(a1):
    obj = Answer()
    try:
        if type(a1) != list:
            raise ValueNotListError
        a1 = sorted(a1)
        obj._Answer__save_ans("kc_1", geth(a1))
    except ValueNotListError:
        print('Please check type of a a1 variable')
        obj._Answer__save_ans("kc_1", geth(False))


def save_question2(f1):
    obj = Answer()
    try:
        if type(f1) != matplotlib.figure.Figure:
            raise ValueNotMatplotlibAxesError
        elif f1.get_figheight() != 10 or f1.get_figwidth() != 30:
            raise ResultDataShapeNotMatchError
        path = "expected_img/expected_boxplot_outliers.png"
        filepath = pkg_resources.resource_filename(__name__, path)
        f1.savefig('actual_box_plot.png', format="png")
        compare_res = compare_images(filepath, 'actual_box_plot.png', tol=20)
        result = "Box Plot Matched Successfully" if compare_res is None else compare_res
        obj._Answer__save_ans("kc_2", geth(result))
    except ValueNotMatplotlibAxesError:
        print('Please check the question2 box plot.')
        obj._Answer__save_ans("kc_2", geth(False))
    except ResultDataShapeNotMatchError:
        print('please check box plot figure size. It should (30, 10)')
        obj._Answer__save_ans("kc_2", geth(False))
    except ImageComparisonFailure:
        print('please check box plot figure and it\'s size')
        obj._Answer__save_ans("kc_2", geth(False))


def save_question3(a2, f2):
    obj = Answer()
    try:
        if type(a2) != int:
            raise ValueNotIntError
        elif type(f2) != matplotlib.figure.Figure:
            raise ValueNotMatplotlibAxesError
        elif f2.get_figheight() != 6 or f2.get_figwidth() != 10:
            raise ResultDataShapeNotMatchError

        path = "expected_img/expected_lineplot_elbow.png"
        filepath = pkg_resources.resource_filename(__name__, path)
        f2.savefig('actual_line_plot.png', format="png")
        compare_res = compare_images(filepath, 'actual_line_plot.png', tol=20)
        result1 = a2
        result2 = "Line Plot Matched Successfully (Elbow)" if compare_res is None else compare_res

        obj._Answer__save_ans("kc_3a", geth(result1))
        obj._Answer__save_ans("kc_3b", geth(result2))
    except ValueNotIntError:
        print('Please check type of a a2 variable')
    except ValueNotMatplotlibAxesError:
        print('Please check the question3 box plot.')
        obj._Answer__save_ans("kc_3a", geth(False))
        obj._Answer__save_ans("kc_3b", geth(False))
    except ResultDataShapeNotMatchError:
        print('please check line plot figure size. It should (10, 6)')
        obj._Answer__save_ans("kc_3a", geth(False))
        obj._Answer__save_ans("kc_3b", geth(False))
    except ImageComparisonFailure:
        print('please check box plot figure and it\'s size')
        obj._Answer__save_ans("kc_3a", geth(False))
        obj._Answer__save_ans("kc_3b", geth(False))


def save_question4(a3):
    obj = Answer()
    try:
        if type(a3) != list:
            raise ValueNotListError
        elif len(a3) != 120:
            raise ListLengthNotMatchError()
        expected_data = [0, 2, 2, 2, 2, 0, 2, 0, 2, 2, 0, 0, 1, 0, 0, 2, 0, 0, 0, 2, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                         0, 0, 0, 0, 1, 2, 0, 3, 0, 0, 0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0,
                         0, 0, 0, 0, 0, 2, 0, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 2, 2, 0, 1, 2, 0, 2, 0, 0, 0, 0, 0, 0, 2,
                         2, 2, 2, 0, 0, 0, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        result = (sum([x == y for x, y in zip(expected_data, a3)]) / 120) * 100
        result = "KMeans Cluster Formation Successfully" if result >= 80.0 else False
        obj._Answer__save_ans("kc_4", geth(result))
    except ValueNotListError:
        print('Please check type of a a3 variable')
        obj._Answer__save_ans("kc_4", geth(False))
    except ListLengthNotMatchError:
        print('Please check a3 list length, existing a3 length is not match origin size')
        obj._Answer__save_ans("kc_4", geth(False))


def save_question5(a4):
    obj = Answer()
    try:
        if type(a4) != int:
            raise ValueNotIntError("Please check type of a a4 variable")
        obj._Answer__save_ans("kc_5", geth(a4))
    except ValueNotIntError as ex:
        print(ex)
        obj._Answer__save_ans("kc_5", geth(False))
