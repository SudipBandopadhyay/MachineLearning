import hashlib
import numpy as np
import pandas as pd
from . import *


def geth(obj):
    obj = str(obj).encode()
    m = hashlib.md5()
    m.update(bytes(obj))
    return m.hexdigest()


def save_question1(a1):
    a1.sort()
    try:
        if type(a1) != list:
            raise ValueNotListError
    except ValueNotListError:
        print('Please check type of a a1 variable')

    obj = Answer()
    obj._Answer__save_ans("hc_1", geth(a1))


def save_question2(a2, a3):
    norm_col_list = ['Normalized 0',
                     'Normalized 1',
                     'Normalized 10',
                     'Normalized 11',
                     'Normalized 12',
                     'Normalized 13',
                     'Normalized 14',
                     'Normalized 15',
                     'Normalized 16',
                     'Normalized 17',
                     'Normalized 18',
                     'Normalized 19',
                     'Normalized 2',
                     'Normalized 20',
                     'Normalized 21',
                     'Normalized 22',
                     'Normalized 23',
                     'Normalized 24',
                     'Normalized 25',
                     'Normalized 26',
                     'Normalized 27',
                     'Normalized 28',
                     'Normalized 29',
                     'Normalized 3',
                     'Normalized 30',
                     'Normalized 31',
                     'Normalized 32',
                     'Normalized 33',
                     'Normalized 34',
                     'Normalized 35',
                     'Normalized 36',
                     'Normalized 37',
                     'Normalized 38',
                     'Normalized 39',
                     'Normalized 4',
                     'Normalized 40',
                     'Normalized 41',
                     'Normalized 42',
                     'Normalized 43',
                     'Normalized 44',
                     'Normalized 45',
                     'Normalized 46',
                     'Normalized 47',
                     'Normalized 48',
                     'Normalized 49',
                     'Normalized 5',
                     'Normalized 50',
                     'Normalized 51',
                     'Normalized 6',
                     'Normalized 7',
                     'Normalized 8',
                     'Normalized 9']
    weekly_col_list = ['W0',
                       'W1',
                       'W10',
                       'W11',
                       'W12',
                       'W13',
                       'W14',
                       'W15',
                       'W16',
                       'W17',
                       'W18',
                       'W19',
                       'W2',
                       'W20',
                       'W21',
                       'W22',
                       'W23',
                       'W24',
                       'W25',
                       'W26',
                       'W27',
                       'W28',
                       'W29',
                       'W3',
                       'W30',
                       'W31',
                       'W32',
                       'W33',
                       'W34',
                       'W35',
                       'W36',
                       'W37',
                       'W38',
                       'W39',
                       'W4',
                       'W40',
                       'W41',
                       'W42',
                       'W43',
                       'W44',
                       'W45',
                       'W46',
                       'W47',
                       'W48',
                       'W49',
                       'W5',
                       'W50',
                       'W51',
                       'W6',
                       'W7',
                       'W8',
                       'W9']
    try:
        if type(a2) != pd.core.frame.DataFrame:
            raise ValueNotDataFrameError
        if type(a3) != pd.core.frame.DataFrame:
            raise ValueNotDataFrameError
    except ValueNotDataFrameError:
        print('Please check type of a a2 or a3 variable')

    obj = Answer()
    obj._Answer__save_ans("hc_2a", geth(a2[norm_col_list]))
    obj._Answer__save_ans("hc_2b", geth(a3[weekly_col_list]))


def save_question3(a4):
    try:
        if type(a4) != list:
            raise ValueNotListError
    except ValueNotListError:
        print('Please check type of a a4 variable')

    a4 = np.round(a4, 2).tolist()

    obj = Answer()
    obj._Answer__save_ans("hc_3", geth(a4))


def save_question4(a5):
    try:
        if type(a5) != int:
            raise ValueNotIntError
    except ValueNotIntError:
        print('Please check type of a a5 variable')

    obj = Answer()
    obj._Answer__save_ans("hc_4", geth(a5))

def save_question5(a6):
    try:
        if type(a6) != int:
            raise ValueNotIntError
    except ValueNotIntError:
        print('Please check type of a a6 variable')

    obj = Answer()
    obj._Answer__save_ans("hc_5", geth(a6))

def save_question6(a7, a8):
    try:
        if type(a7) != int:
            raise ValueNotIntError
        if type(a8) != int:
            raise ValueNotIntError
    except ValueNotIntError:
        print('Please check type of a a7 or a8 variable')

    obj = Answer()
    obj._Answer__save_ans("hc_6a", geth(a7))
    obj._Answer__save_ans("hc_6b", geth(a8))
