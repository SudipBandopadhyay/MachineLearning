import hashlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.testing.compare import compare_images
from matplotlib.testing.compare import ImageComparisonFailure
import matplotlib
import pkg_resources
from . import *


def geth(obj):
    obj = str(obj).encode()
    m = hashlib.md5()
    m.update(bytes(obj))
    return m.hexdigest()


def save_question1(a1):
    obj = Answer()
    try:
        if type(a1) != pd.core.frame.DataFrame:
            raise ValueNotDataFrameError
        col_list = ['BALANCE', 'BALANCE_FREQUENCY', 'PURCHASES', 'ONEOFF_PURCHASES',
                    'INSTALLMENTS_PURCHASES',
                    'CASH_ADVANCE', 'PURCHASES_FREQUENCY', 'ONEOFF_PURCHASES_FREQUENCY',
                    'PURCHASES_INSTALLMENTS_FREQUENCY',
                    'CASH_ADVANCE_FREQUENCY', 'CASH_ADVANCE_TRX', 'PURCHASES_TRX', 'CREDIT_LIMIT', 'PAYMENTS',
                    'MINIMUM_PAYMENTS',
                    'PRC_FULL_PAYMENT', 'TENURE']
        obj._Answer__save_ans("kc_1a", geth(np.round(a1[col_list].head().values, 1).tolist()))
        obj._Answer__save_ans("kc_1b", geth(int(a1.isnull().sum().sum())))
    except ValueNotDataFrameError:
        print('Please check type of a a1 variable')
        obj._Answer__save_ans("kc_1a", geth(False))
        obj._Answer__save_ans("kc_1b", geth(False))


def save_question2(a2):
    obj = Answer()
    try:
        if type(a2) != list:
            raise ValueNotListError
        a2 = sorted(a2)
        obj._Answer__save_ans("kc_2", geth(a2))
    except ValueNotListError:
        print('Please check type of a a2 variable')
        obj._Answer__save_ans("kc_2", geth(False))


def save_question3(a3):
    obj = Answer()
    try:
        if type(a3) != pd.core.frame.DataFrame:
            raise ValueNotDataFrameError
        col_list = ['BALANCE',
                    'BALANCE_FREQUENCY',
                    'CASH_ADVANCE',
                    'CASH_ADVANCE_FREQUENCY',
                    'CASH_ADVANCE_TRX',
                    'CREDIT_LIMIT',
                    'INSTALLMENTS_PURCHASES',
                    'MINIMUM_PAYMENTS',
                    'ONEOFF_PURCHASES',
                    'ONEOFF_PURCHASES_FREQUENCY',
                    'PAYMENTS',
                    'PRC_FULL_PAYMENT',
                    'PURCHASES',
                    'PURCHASES_FREQUENCY',
                    'PURCHASES_INSTALLMENTS_FREQUENCY',
                    'PURCHASES_TRX',
                    'TENURE']
        obj._Answer__save_ans("kc_3", geth(np.round(a3[col_list].head().values, 1).tolist()))
    except ValueNotDataFrameError:
        print('Please check type of a a3 variable')
        obj._Answer__save_ans("kc_3", geth(False))


def save_question4(f):
    obj = Answer()
    try:
        if type(f) != matplotlib.figure.Figure:
            raise ValueNotMatplotlibAxesError
        elif f.get_figheight() != 10 or f.get_figwidth() != 30:
            raise ResultDataShapeNotMatchError
        path = "expected_img/expected_boxplot_outliers.png"
        filepath = pkg_resources.resource_filename(__name__, path)
        f.savefig('actual_box_plot.png', format="png")
        compare_res = compare_images(filepath, 'actual_box_plot.png', tol=20)
        result = "Box Plot Matched Successfully" if compare_res is None else compare_res
        obj._Answer__save_ans("kc_4", geth(result))
    except ValueNotMatplotlibAxesError:
        print('Please check the question4 box plot.')
        obj._Answer__save_ans("kc_4", geth(False))
    except ResultDataShapeNotMatchError:
        print('please check box plot figure size. It should (30, 10)')
        obj._Answer__save_ans("kc_4", geth(False))
    except ImageComparisonFailure:
        print('please check box plot figure and it\'s size')
        obj._Answer__save_ans("kc_4", geth(False))


def save_question5(a4):
    obj = Answer()
    try:
        if type(a4) != list:
            raise ValueNotListError
        a4 = sorted(a4)
        obj._Answer__save_ans("kc_5", geth(a4))
    except ValueNotListError:
        print('Please check type of a a4 variable')
        obj._Answer__save_ans("kc_5", geth(False))


def save_question6(a5, f2):
    obj = Answer()
    try:
        if type(a5) != int:
            raise ValueNotIntError
        elif type(f2) != matplotlib.figure.Figure:
            raise ValueNotMatplotlibAxesError
        elif f2.get_figheight() != 6 or f2.get_figwidth() != 10:
            raise ResultDataShapeNotMatchError

        path = "expected_img/expected_lineplot_elbow.png"
        filepath = pkg_resources.resource_filename(__name__, path)
        f2.savefig('actual_line_plot.png', format="png")
        compare_res = compare_images(filepath, 'actual_line_plot.png', tol=20)
        result1 = (a5 == 5)
        result2 = "Line Plot Matched Successfully (Elbow)" if compare_res is None else compare_res

        obj._Answer__save_ans("kc_6a", geth(result1))
        obj._Answer__save_ans("kc_6b", geth(result2))
    except ValueNotIntError:
        print('Please check type of a a5 variable')
    except ValueNotMatplotlibAxesError:
        print('Please check the question6 box plot.')
        obj._Answer__save_ans("kc_6a", geth(False))
        obj._Answer__save_ans("kc_6b", geth(False))
    except ResultDataShapeNotMatchError:
        print('please check line plot figure size. It should (10, 6)')
        obj._Answer__save_ans("kc_6a", geth(False))
        obj._Answer__save_ans("kc_6b", geth(False))
    except ImageComparisonFailure:
        print('please check box plot figure and it\'s size')
        obj._Answer__save_ans("kc_6a", geth(False))
        obj._Answer__save_ans("kc_6b", geth(False))


def save_question7(a6, a7):
    obj = Answer()
    try:
        if type(a6) != int:
            raise ValueNotIntError("Please check type of a a6 variable")
        elif type(a7) != int:
            raise ValueNotIntError("Please check type of a a7 variable")
        obj._Answer__save_ans("kc_7a", geth(a6))
        obj._Answer__save_ans("kc_7b", geth(a7))
    except ValueNotIntError as ex:
        print(ex)
        obj._Answer__save_ans("kc_7a", geth(a6))
        obj._Answer__save_ans("kc_7b", geth(a7))


