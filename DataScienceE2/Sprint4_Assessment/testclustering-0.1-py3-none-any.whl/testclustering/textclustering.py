import hashlib
import numpy as np
import pandas as pd
import matplotlib
from wordcloud import WordCloud
from sklearn.metrics import silhouette_score
from . import *


def geth(obj):
    obj = str(obj).encode()
    m = hashlib.md5()
    m.update(bytes(obj))
    return m.hexdigest()


def save_question1(a1):
    col_list = ['summary']

    try:
        if type(a1) != pd.core.frame.DataFrame:
            raise ValueNotDataFrameError
    except ValueNotDataFrameError:
        print('Please check type of a a1 variable')

    obj = Answer()
    obj._Answer__save_ans("tc_1", geth(a1[col_list]))


def save_question2(a2):
    col_list = ['summary']

    try:
        if type(a2) != pd.core.frame.DataFrame:
            raise ValueNotDataFrameError
    except ValueNotDataFrameError:
        print('Please check type of a a2 variable')

    obj = Answer()
    obj._Answer__save_ans("tc_2", geth(a2[col_list]))


def save_question3(a3):
    try:
        if type(a3) != WordCloud:
            raise ValueNotWorldCloudObject
    except ValueNotWorldCloudObject:
        print('Please check type of a a3 variable')
    rounded_values = {k: '%.5f' % (value) for k, value in a3.words_.items()}
    obj = Answer()
    obj._Answer__save_ans("tc_3", geth(sorted(rounded_values.items())))


def save_question4(a4):
    try:
        if type(a4) != np.ndarray:
            raise ValueNotNumpyArray
    except ValueNotNumpyArray:
        print('Please check type of a a4 variable')

    obj = Answer()
    obj._Answer__save_ans("tc_4", geth(a4))


def save_question5(a5):
    try:
        if type(a5) != int:
            raise ValueNotIntError
    except ValueNotIntError:
        print('Please check type of a a5 variable')

    obj = Answer()
    obj._Answer__save_ans("tc_5", geth(a5))


def save_question6(a6, a7):
    try:
        if type(a6) != int:
            raise ValueNotIntError
        if type(a7) != matplotlib.axes.Subplot:
            raise ValueNotMatplotlibAxesError

    except ValueNotIntError:
        print('Please check type of a a6 variable')
    except ValueNotMatplotlibAxesError:
        print('Please check type of a a7 variable')

    y_data = np.round(a7.get_lines()[0].get_ydata(), 2).tolist()

    obj = Answer()
    obj._Answer__save_ans("tc_6a", geth(a6 >= 18))
    obj._Answer__save_ans("tc_6b", geth(y_data))


def save_question7(a8, a9):
    try:
        if type(a8) != np.ndarray:
            raise ValueNotNumpyArray
        if type(a9) != np.ndarray:
            raise ValueNotNumpyArray
    except ValueNotNumpyArray:
        print('Please check type of a a8 or a9 variable')

    obj = Answer()
    obj._Answer__save_ans("tc_7", geth((silhouette_score(a8, a9) > 0.017)))
